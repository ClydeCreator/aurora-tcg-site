export default function Home() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Bienvenue dans Aurora TCG</h1>
      <p>Découvrez un jeu de cartes interactif où l'Alliance et la Rébellion s'affrontent.</p>
    </div>
  );
}
