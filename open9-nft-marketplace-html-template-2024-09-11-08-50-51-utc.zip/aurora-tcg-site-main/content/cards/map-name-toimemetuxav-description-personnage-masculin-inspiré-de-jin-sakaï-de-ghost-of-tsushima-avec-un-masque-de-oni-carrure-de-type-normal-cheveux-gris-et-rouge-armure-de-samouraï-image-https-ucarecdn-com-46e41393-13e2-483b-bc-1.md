---
name: Toimemetuxav
description: Personnage masculin inspiré de Jin Sakaï de Ghost of Tsushima avec
  un masque de Oni. Carrure de type normal. Cheveux Gris et rouge. Armure de
  samouraï.
image: https://ucarecdn.com/46e41393-13e2-483b-bc13-403395fce027/
---
